from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime, timezone
from typing import List, Optional, Dict
from core.database import db
from core.clients import llm_client
from core.utils import logger
from models.base import Message
from models.project import ChatRequest, AgentChainRequest
import json
import re

router = APIRouter(tags=["chat"])


def extract_code_blocks(content: str) -> List[Dict[str, str]]:
    pattern = r'```(\w+)?(?::([^\n]+))?\n([\s\S]*?)```'
    matches = re.findall(pattern, content)
    blocks = []
    for match in matches:
        language = match[0] or "text"
        filepath = match[1] or ""
        code = match[2].strip()
        filename = filepath.split('/')[-1] if filepath else f"code.{language}"
        blocks.append({
            "language": language,
            "filepath": filepath,
            "filename": filename,
            "content": code
        })
    return blocks


def extract_delegations(content: str) -> List[Dict[str, str]]:
    """Extract delegation blocks from COMMANDER's response"""
    pattern = r'\[DELEGATE:(\w+)\]([\s\S]*?)\[/DELEGATE\]'
    matches = re.findall(pattern, content)
    delegations = []
    for match in matches:
        agent_name = match[0].upper()
        task = match[1].strip()
        delegations.append({"agent": agent_name, "task": task})
    return delegations


async def build_project_context(project_id: str) -> str:
    project = await db.projects.find_one({"id": project_id}, {"_id": 0})
    if not project:
        return ""
    
    context_parts = [
        f"PROJECT: {project['name']}",
        f"TYPE: {project['type']}",
        f"ENGINE: {project.get('engine_version', 'N/A')}",
        f"STATUS: {project['status']}",
        f"PHASE: {project.get('phase', 'clarification')}",
        f"DESCRIPTION: {project['description']}"
    ]
    
    plan = await db.plans.find_one({"project_id": project_id}, {"_id": 0})
    if plan and plan.get('approved'):
        context_parts.append(f"\nAPPROVED PLAN:\n{plan.get('overview', '')}")
        context_parts.append(f"ARCHITECTURE:\n{plan.get('architecture', '')}")
    
    memories = await db.memories.find(
        {"project_id": project_id},
        {"_id": 0}
    ).sort("importance", -1).limit(10).to_list(10)
    
    if memories:
        context_parts.append("\nAGENT MEMORIES (remember these):")
        for mem in memories:
            context_parts.append(f"  [{mem['agent_name']}] {mem['content']}")
    
    files = await db.files.find({"project_id": project_id}, {"_id": 0}).to_list(50)
    if files:
        context_parts.append(f"\nEXISTING FILES ({len(files)}):")
        for f in files[:20]:
            context_parts.append(f"  - {f['filepath']}")
    
    messages = await db.messages.find(
        {"project_id": project_id}, {"_id": 0}
    ).sort("timestamp", -1).limit(5).to_list(5)
    
    if messages:
        context_parts.append("\nRECENT CONVERSATION:")
        for msg in reversed(messages):
            content_preview = msg['content'][:150] + "..." if len(msg['content']) > 150 else msg['content']
            context_parts.append(f"  {msg['agent_name']}: {content_preview}")
    
    return "\n".join(context_parts)


async def get_or_create_agents():
    from routes.agents import get_or_create_agents as _get_agents
    return await _get_agents()


async def call_agent(agent: dict, messages: List[dict], project_context: str = "") -> str:
    system_message = agent['system_prompt']
    if project_context:
        system_message += f"\n\nCURRENT PROJECT CONTEXT:\n{project_context}"
    
    try:
        response = llm_client.chat.completions.create(
            model=agent.get('model', 'google/gemini-2.5-flash'),
            messages=[
                {"role": "system", "content": system_message},
                *messages
            ],
            max_tokens=8000,
            temperature=0.7
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Error calling agent {agent['name']}: {e}")
        raise HTTPException(status_code=500, detail=f"Agent call failed: {str(e)}")


@router.post("/chat")
async def chat_with_team(request: ChatRequest):
    context = await build_project_context(request.project_id)
    agents = await get_or_create_agents()
    
    target_agent = None
    if request.delegate_to:
        target_agent = next((a for a in agents if a['name'].upper() == request.delegate_to.upper()), None)
    
    if not target_agent:
        target_agent = next((a for a in agents if a['role'] == 'lead'), agents[0])
    
    await db.agents.update_one({"id": target_agent['id']}, {"$set": {"status": "thinking"}})
    
    messages = [{"role": "user", "content": request.message}]
    response = await call_agent(target_agent, messages, context)
    
    await db.agents.update_one({"id": target_agent['id']}, {"$set": {"status": "idle"}})
    
    user_msg = Message(
        project_id=request.project_id,
        agent_id="user",
        agent_name="You",
        agent_role="user",
        content=request.message,
        phase=request.phase
    )
    user_doc = user_msg.model_dump()
    user_doc['timestamp'] = user_doc['timestamp'].isoformat()
    await db.messages.insert_one(user_doc)
    
    code_blocks = extract_code_blocks(response)
    delegations = extract_delegations(response)
    
    agent_msg = Message(
        project_id=request.project_id,
        agent_id=target_agent['id'],
        agent_name=target_agent['name'],
        agent_role=target_agent['role'],
        content=response,
        code_blocks=code_blocks,
        phase=request.phase
    )
    agent_doc = agent_msg.model_dump()
    agent_doc['timestamp'] = agent_doc['timestamp'].isoformat()
    await db.messages.insert_one(agent_doc)
    
    return {
        "response": response,
        "code_blocks": code_blocks,
        "delegations": delegations,
        "agent": {
            "id": target_agent['id'],
            "name": target_agent['name'],
            "role": target_agent['role'],
            "avatar": target_agent['avatar']
        }
    }


@router.post("/chat/stream")
async def stream_chat(request: ChatRequest):
    """Stream chat response with SSE"""
    context = await build_project_context(request.project_id)
    agents = await get_or_create_agents()
    
    target_agent = None
    if request.delegate_to:
        target_agent = next((a for a in agents if a['name'].upper() == request.delegate_to.upper()), None)
    if not target_agent:
        target_agent = next((a for a in agents if a['role'] == 'lead'), agents[0])
    
    user_msg = Message(
        project_id=request.project_id,
        agent_id="user",
        agent_name="You",
        agent_role="user",
        content=request.message,
        phase=request.phase
    )
    user_doc = user_msg.model_dump()
    user_doc['timestamp'] = user_doc['timestamp'].isoformat()
    await db.messages.insert_one(user_doc)
    
    messages = [{"role": "user", "content": request.message}]
    
    async def generate():
        await db.agents.update_one({"id": target_agent['id']}, {"$set": {"status": "thinking"}})
        
        yield f"data: {json.dumps({'type': 'start', 'agent': {'id': target_agent['id'], 'name': target_agent['name'], 'role': target_agent['role'], 'avatar': target_agent['avatar']}})}\n\n"
        
        full_content = ""
        try:
            stream = llm_client.chat.completions.create(
                model=target_agent.get('model', 'google/gemini-2.5-flash'),
                messages=[
                    {"role": "system", "content": target_agent['system_prompt'] + f"\n\nCONTEXT:\n{context}"},
                    *messages
                ],
                max_tokens=8000,
                temperature=0.7,
                stream=True
            )
            
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                    content = chunk.choices[0].delta.content
                    full_content += content
                    yield f"data: {json.dumps({'type': 'content', 'content': content})}\n\n"
            
            code_blocks = extract_code_blocks(full_content)
            delegations = extract_delegations(full_content)
            
            agent_msg = Message(
                project_id=request.project_id,
                agent_id=target_agent['id'],
                agent_name=target_agent['name'],
                agent_role=target_agent['role'],
                content=full_content,
                code_blocks=code_blocks,
                phase=request.phase
            )
            agent_doc = agent_msg.model_dump()
            agent_doc['timestamp'] = agent_doc['timestamp'].isoformat()
            await db.messages.insert_one(agent_doc)
            
            yield f"data: {json.dumps({'type': 'done', 'code_blocks': code_blocks, 'delegations': delegations})}\n\n"
            
        except Exception as e:
            logger.error(f"Stream error: {e}")
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"
        finally:
            await db.agents.update_one({"id": target_agent['id']}, {"$set": {"status": "idle"}})
    
    return StreamingResponse(generate(), media_type="text/event-stream")


@router.post("/delegate")
async def execute_delegation(request: ChatRequest):
    """Execute a delegated task to a specific agent"""
    agents = await get_or_create_agents()
    
    if not request.delegate_to:
        raise HTTPException(status_code=400, detail="delegate_to is required")
    
    target_agent = next((a for a in agents if a['name'].upper() == request.delegate_to.upper()), None)
    if not target_agent:
        raise HTTPException(status_code=404, detail=f"Agent {request.delegate_to} not found")
    
    context = await build_project_context(request.project_id)
    
    await db.agents.update_one({"id": target_agent['id']}, {"$set": {"status": "working"}})
    
    messages = [{"role": "user", "content": f"COMMANDER has delegated this task to you:\n\n{request.message}"}]
    response = await call_agent(target_agent, messages, context)
    
    await db.agents.update_one({"id": target_agent['id']}, {"$set": {"status": "idle"}})
    
    code_blocks = extract_code_blocks(response)
    
    delegation_msg = Message(
        project_id=request.project_id,
        agent_id=target_agent['id'],
        agent_name=target_agent['name'],
        agent_role=target_agent['role'],
        content=response,
        code_blocks=code_blocks,
        message_type="delegation",
        delegated_to=target_agent['name']
    )
    msg_doc = delegation_msg.model_dump()
    msg_doc['timestamp'] = msg_doc['timestamp'].isoformat()
    await db.messages.insert_one(msg_doc)
    
    return {
        "response": response,
        "code_blocks": code_blocks,
        "agent": {
            "id": target_agent['id'],
            "name": target_agent['name'],
            "role": target_agent['role'],
            "avatar": target_agent['avatar']
        }
    }


@router.get("/messages")
async def get_messages(project_id: str, limit: int = 100):
    return await db.messages.find({"project_id": project_id}, {"_id": 0}).sort("timestamp", 1).to_list(limit)
